"""
Continuous Transaction Producer for Kafka

Purpose:
- Simulates a real-world transaction-generating application
- Continuously produces transaction events to a Kafka topic
- Demonstrates key-based partitioning (3 partitions)

Architecture Position:
Producer (Application Layer)
        ↓
Kafka Topic: transactions (3 partitions)

Kafka Version : 3.2.3
Platform      : Windows
"""

# ------------------------------------------------------------
# 1. IMPORT REQUIRED LIBRARIES
# ------------------------------------------------------------
# time      → controls event frequency
# random    → generates realistic random data
# datetime  → adds event timestamps
# KafkaProducer → sends messages to Kafka

import time
import random
from datetime import datetime
from kafka import KafkaProducer


# ------------------------------------------------------------
# 2. KAFKA PRODUCER CONFIGURATION
# ------------------------------------------------------------
# - bootstrap_servers : Kafka broker address
# - key_serializer    : Converts key (user_id) to bytes
# - value_serializer  : Converts message payload to bytes
#
# Kafka uses the MESSAGE KEY to decide the partition.
# Same key → same partition (important for ordering).

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    key_serializer=lambda k: k.encode("utf-8"),
    value_serializer=lambda v: v.encode("utf-8")
)

# Kafka topic name
topic = "transactions"


# ------------------------------------------------------------
# 3. MASTER DATA (SIMULATED BUSINESS DATA)
# ------------------------------------------------------------
# This represents users and transaction types in a real system.

users = ["U101", "U102", "U103", "U104", "U105"]
txn_types = ["DEBIT", "CREDIT"]

# Transaction counter to generate unique transaction IDs
txn_counter = 1000

print("✅ Continuous Transaction Producer started")
print("👉 Sending transactions to Kafka topic:", topic)


# ------------------------------------------------------------
# 4. CONTINUOUS EVENT GENERATION LOOP
# ------------------------------------------------------------
# This loop simulates a live system producing transactions
# every few seconds.

try:
    while True:
        # Increment transaction ID
        txn_counter += 1

        # Select random user and transaction details
        user_id = random.choice(users)
        txn_id = f"TXN{txn_counter}"
        amount = random.randint(100, 5000)
        currency = "INR"
        txn_type = random.choice(txn_types)
        txn_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Construct transaction message (CSV format)
        # Format:
        # txn_id,user_id,amount,currency,txn_type,txn_time
        message = (
            f"{txn_id},{user_id},{amount},"
            f"{currency},{txn_type},{txn_time}"
        )

        # ----------------------------------------------------
        # 5. SEND MESSAGE TO KAFKA
        # ----------------------------------------------------
        # KEY   = user_id (controls partition selection)
        # VALUE = transaction record
        #
        # Kafka ensures:
        # - Same user_id → same partition
        # - Order preserved per user

        producer.send(
            topic=topic,
            key=user_id,
            value=message
        )

        # Ensure message is actually sent
        producer.flush()

        # Log sent message
        print(f"➡️ Sent | key={user_id} | value={message}")

        # Wait before sending next transaction
        time.sleep(2)

except KeyboardInterrupt:
    # Graceful shutdown when user presses Ctrl+C
    print("\n🛑 Producer interrupted by user")

finally:
    # --------------------------------------------------------
    # 6. CLEAN SHUTDOWN
    # --------------------------------------------------------
    # Close producer connection and release resources
    producer.close()
    print("✅ Kafka producer closed cleanly")






# kafka-topics.bat --create --bootstrap-server localhost:9092 --topic transactions --partitions 3 --replication-factor 1

# VERIFY IT IS WORKING
# kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic transactions --property print.key=true --property print.partition=true


# You’ll see:

# Partition:1 Key:U102 TXN1005,U102,4500,INR,DEBIT,...
# Partition:0 Key:U101 TXN1006,U101,1200,INR,CREDIT,...