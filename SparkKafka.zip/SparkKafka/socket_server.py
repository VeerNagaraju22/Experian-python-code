"""
Socket Text Producer
====================
Purpose:
- Acts as a real-time data producer
- Sends user-entered text continuously to a TCP socket
- Used as a lightweight streaming source for Spark Structured Streaming

Architecture Position:
Producer (Application Layer)
        ↓
TCP Socket (localhost:9999)
"""

import socket

# ------------------------------------------------------------
# 1️⃣ DEFINE HOST AND PORT
# ------------------------------------------------------------
# Spark Structured Streaming will connect to this host and port
# to receive streaming data.

HOST = "localhost"
PORT = 9999


# ------------------------------------------------------------
# 2️⃣ CREATE TCP SOCKET SERVER
# ------------------------------------------------------------
# AF_INET  → IPv4
# SOCK_STREAM → TCP connection (reliable, ordered)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to host and port
server.bind((HOST, PORT))

# Listen for incoming client connections (Spark is the client)
server.listen(1)

print(f"✅ Socket server started on {HOST}:{PORT}")
print("⏳ Waiting for Spark to connect...")


# ------------------------------------------------------------
# 3️⃣ ACCEPT CONNECTION FROM SPARK
# ------------------------------------------------------------
# Spark Structured Streaming connects as a client.
# This call blocks until Spark connects.

conn, addr = server.accept()
print(f"🔗 Spark connected from {addr}")


# ------------------------------------------------------------
# 4️⃣ CONTINUOUSLY SEND DATA
# ------------------------------------------------------------
# Each line typed by the user is sent to Spark as a new event.
# This simulates a live data feed.

try:
    while True:
        msg = input("> ")  # User types data here

        # Graceful shutdown command
        if msg.lower() in ("exit", "quit"):
            print("🛑 Stopping producer")
            break

        # Send message followed by newline (important for Spark socket source)
        conn.send((msg + "\n").encode())

except KeyboardInterrupt:
    print("\n🛑 Producer interrupted by user")

finally:
    # --------------------------------------------------------
    # 5️⃣ CLEAN SHUTDOWN
    # --------------------------------------------------------
    # Always close socket connections to free resources
    conn.close()
    server.close()
    print("✅ Socket server closed cleanly")
