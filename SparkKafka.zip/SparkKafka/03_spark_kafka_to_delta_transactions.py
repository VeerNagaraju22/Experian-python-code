"""
Spark Structured Streaming: Kafka → Delta Lake (ACID)
FINAL WORKING VERSION (Windows)

Pipeline:
Kafka (3 partitions) → Spark Structured Streaming → Delta Lake (Local)

Compatibility:
- Spark        : 3.3.4
- Delta Lake   : 2.3.0  (IMPORTANT)
- Kafka        : 3.2.3
- Scala        : 2.12
- Java         : 8
"""

# ------------------------------------------------------------
# 1. WINDOWS + SPARK INITIALIZATION (MANDATORY)
# ------------------------------------------------------------

import os
import findspark

# 🔴 UPDATE THESE PATHS ONLY IF THEY DIFFER ON YOUR MACHINE
os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Initialize Spark so PySpark can find it
findspark.init(os.environ["SPARK_HOME"])

# ------------------------------------------------------------
# 2. LOAD REQUIRED SPARK PACKAGES
# ------------------------------------------------------------
# ✔ Delta Lake 2.3.0  → compatible with Spark 3.3.x
# ✔ Kafka connector  → required for .format("kafka")

os.environ["PYSPARK_SUBMIT_ARGS"] = (
    "--packages "
    "io.delta:delta-core_2.12:2.3.0,"
    "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.4 "
    "pyspark-shell"
)

# ------------------------------------------------------------
# 3. CREATE SPARK SESSION (DELTA ENABLED)
# ------------------------------------------------------------

from pyspark.sql import SparkSession
from pyspark.sql.functions import split

spark = SparkSession.builder \
    .appName("KafkaTransactionsToDelta") \
    .master("local[*]") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

print("✅ Spark started successfully")
print("👉 Consuming Kafka topic: transactions")

# ------------------------------------------------------------
# 4. READ STREAMING DATA FROM KAFKA
# ------------------------------------------------------------
# Spark automatically reads ALL partitions in parallel

kafka_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "transactions") \
    .option("startingOffsets", "latest") \
    .load()

# ------------------------------------------------------------
# 5. PARSE TRANSACTION MESSAGE (CSV → STRUCTURED DATA)
# ------------------------------------------------------------

transactions_df = kafka_df.selectExpr("CAST(value AS STRING)") \
    .select(
        split("value", ",").getItem(0).alias("txn_id"),
        split("value", ",").getItem(1).alias("user_id"),
        split("value", ",").getItem(2).cast("double").alias("amount"),
        split("value", ",").getItem(3).alias("currency"),
        split("value", ",").getItem(4).alias("txn_type"),
        split("value", ",").getItem(5).alias("txn_time")
    )

# ------------------------------------------------------------
# 6. WRITE STREAM TO DELTA LAKE (ACID ENABLED)
# ------------------------------------------------------------
# Each micro-batch = ONE atomic Delta transaction

query = transactions_df.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", r"C:\delta\checkpoints\transactions") \
    .start(r"C:\delta\tables\transactions")

print("✅ Streaming started: Kafka → Delta Lake (ACID)")

# ------------------------------------------------------------
# 7. KEEP STREAMING RUNNING
# ------------------------------------------------------------

query.awaitTermination()





# Micro-batch starts
#    ↓
# Write Parquet (hidden)
#    ↓
# Write _delta_log (commit)
#    ↓
# Data visible
#    ↓
# Update checkpoint


# Spark writes in batches

# Delta commits each batch safely

# No half data

# No duplicates

# No data loss

# That’s ACID in your pipeline.