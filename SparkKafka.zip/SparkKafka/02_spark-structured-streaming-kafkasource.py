# ============================================================
# Spark Structured Streaming from Kafka
# Spark 3.3.4 | Kafka 3.2.3 | Windows
# ============================================================

# ------------------------------------------------------------
# 1️⃣ ENVIRONMENT SETUP
# ------------------------------------------------------------
import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

os.environ["PYSPARK_SUBMIT_ARGS"] = (
    "--packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.4 pyspark-shell"
)

findspark.init(r"C:\spark-3.3.4-bin-hadoop2")

# ------------------------------------------------------------
# 2️⃣ CREATE SPARK SESSION
# ------------------------------------------------------------
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("Kafka_Structured_Streaming_Final") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
print("✅ Spark Version:", spark.version)

# ------------------------------------------------------------
# 3️⃣ READ STREAMING DATA FROM KAFKA
# ------------------------------------------------------------
kafka_df = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "localhost:9092")
    .option("subscribe", "emps")
    .option("startingOffsets", "latest")
    .load()
    .selectExpr("CAST(value AS STRING) AS value")
)

# ------------------------------------------------------------
# 4️⃣ DEFINE SCHEMA
# ------------------------------------------------------------
from pyspark.sql.types import StructType, StructField, StringType, FloatType

emp_schema = StructType([
    StructField("id", StringType()),
    StructField("name", StringType()),
    StructField("salary", FloatType()),
    StructField("dept_id", StringType())
])

# ------------------------------------------------------------
# 5️⃣ PARSE KAFKA MESSAGE
# ------------------------------------------------------------
from pyspark.sql.functions import split

def parse_kafka_message(df, schema):
    cols = split(df["value"], ",")
    for i, field in enumerate(schema):
        df = df.withColumn(field.name, cols.getItem(i).cast(field.dataType))
    return df.select([field.name for field in schema])

emp_df = parse_kafka_message(kafka_df, emp_schema)

# ------------------------------------------------------------
# 6️⃣ AGGREGATION
# ------------------------------------------------------------
emp_count_df = emp_df.groupBy("id").count()

# ------------------------------------------------------------
# 7️⃣ WRITE STREAM WITH CHECKPOINTING
# ------------------------------------------------------------
query = (
    emp_count_df
    .writeStream
    .queryName("emp_data")
    .outputMode("complete")
    .format("memory")
    .option("checkpointLocation", r"C:\spark-checkpoints\kafka_emp")
    .start()
)

print("✅ Kafka Structured Streaming started")

# ------------------------------------------------------------
# 8️⃣ SIMPLE LIVE DISPLAY LOOP 
# ------------------------------------------------------------
import time

try:
    while True:
        print("\n===== CURRENT STREAM DATA =====")
        spark.sql("SELECT * FROM emp_data").show(truncate=False)
        time.sleep(5)

except KeyboardInterrupt:
    print("🛑 Stopping streaming...")
    query.stop()
    spark.stop()



# kafka-topics.bat --create --bootstrap-server localhost:9092 --topic emps --partitions 1 --replication-factor 1

# kafka-console-producer.bat --bootstrap-server localhost:9092 --topic emps

# 101,John,50000,10
# 102,Alice,60000,20
# 103,Bob,55000,10
