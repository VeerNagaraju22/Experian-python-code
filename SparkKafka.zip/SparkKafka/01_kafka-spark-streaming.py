# ============================================================
# Spark → Kafka Producer (Professional Implementation)
#
# Use Case : Employee Activity Events
# Purpose  : Demonstrate Spark acting as a Kafka producer
# Author   : Data Engineering Team
#
# Spark    : 3.3.4
# Kafka    : 3.2.3
# Platform : Windows
# ============================================================


# ------------------------------------------------------------
# 1. ENVIRONMENT INITIALIZATION
# ------------------------------------------------------------
# Configure runtime paths so Spark and Java can be located
# correctly when running on Windows.

import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Add Kafka connector dependency dynamically
os.environ["PYSPARK_SUBMIT_ARGS"] = (
    "--packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.4 pyspark-shell"
)

findspark.init(r"C:\spark-3.3.4-bin-hadoop2")


# ------------------------------------------------------------
# 2. SPARK SESSION CREATION
# ------------------------------------------------------------
# SparkSession is the main entry point to Spark functionality.

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("EmployeeActivityKafkaProducer") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")


# ------------------------------------------------------------
# 3. BUSINESS DOMAIN DATA
# ------------------------------------------------------------
# Define static master data to simulate a real enterprise
# environment. This makes demonstrations meaningful.

employees = [
    ("101", "John", "HYD"),
    ("102", "Alice", "BLR"),
    ("103", "Rahul", "PUNE"),
    ("104", "Meena", "CHN")
]

actions = [
    "LOGIN",
    "LOGOUT",
    "VIEW_DASHBOARD",
    "DOWNLOAD_REPORT",
    "UPDATE_PROFILE"
]


# ------------------------------------------------------------
# 4. EVENT GENERATION LOGIC
# ------------------------------------------------------------
# Each execution generates one activity event per employee.
# This mimics real-time application behavior.

from datetime import datetime
import random

event_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

events = [
    (
        emp_id,                        # Employee ID
        name,                          # Employee Name
        random.choice(actions),        # Activity Type
        event_timestamp,               # Event Time
        location                       # Location
    )
    for emp_id, name, location in employees
]

schema_columns = [
    "emp_id",
    "name",
    "action",
    "event_time",
    "location"
]


# ------------------------------------------------------------
# 5. CREATE SPARK DATAFRAME
# ------------------------------------------------------------
# Convert raw Python objects into a Spark DataFrame to enable
# schema enforcement and distributed processing.

events_df = spark.createDataFrame(events, schema_columns)


# ------------------------------------------------------------
# 6. DATA QUALITY ENFORCEMENT
# ------------------------------------------------------------
# Ensure one unique event per employee per run to avoid
# duplicate Kafka messages.

events_df = events_df.dropDuplicates(["emp_id"])


# ------------------------------------------------------------
# 7. SERIALIZATION FOR KAFKA
# ------------------------------------------------------------
# Kafka expects messages as key/value pairs.
# We serialize each row into a CSV string for the value field.

from pyspark.sql.functions import concat_ws

kafka_messages_df = events_df.select(
    concat_ws(
        ",",
        "emp_id",
        "name",
        "action",
        "event_time",
        "location"
    ).alias("value")
)


# ------------------------------------------------------------
# 8. WRITE DATA TO KAFKA
# ------------------------------------------------------------
# Spark now behaves as a Kafka producer.
# Each DataFrame row is published as a Kafka message.

kafka_messages_df.selectExpr("CAST(value AS STRING)") \
    .write \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "emp_activity") \
    .save()

print("✅ Employee activity events successfully sent to Kafka")


# ------------------------------------------------------------
# 9. GRACEFUL SHUTDOWN
# ------------------------------------------------------------
# Always stop Spark to release resources cleanly.

spark.stop()



#kafka-topics.bat --create --bootstrap-server localhost:9092 --topic emp_activity --partitions 1 --replication-factor 1


#kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic emp_activity --from-beginning
