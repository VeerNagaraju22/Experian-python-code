# ============================================================
# Spark Structured Streaming – Session Window Word Count
# ============================================================

"""
Purpose:
- Reads real-time text data from a socket
- Splits text into words
- Groups words into sessions based on inactivity gap
- Counts words per session
- Displays results continuously

Session Configuration:
- Session Gap: 10 seconds
  (If no data arrives for 10 seconds, session closes)

Architecture:
Socket Server
      ↓
Spark Structured Streaming
      ↓
Session Window Aggregation
      ↓
Console Output
"""

# ------------------------------------------------------------
# 1️⃣ ENVIRONMENT SETUP (WINDOWS)
# ------------------------------------------------------------
import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

findspark.init(os.environ["SPARK_HOME"])

# ------------------------------------------------------------
# 2️⃣ CREATE SPARK SESSION
# ------------------------------------------------------------
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split, current_timestamp, session_window

spark = SparkSession.builder \
    .appName("SessionWindowWordCount") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

print("✅ Spark started")
print("👉 Waiting for data from socket...")

# ------------------------------------------------------------
# 3️⃣ READ STREAMING DATA FROM SOCKET
# ------------------------------------------------------------
lines = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

# ------------------------------------------------------------
# 4️⃣ ADD EVENT-TIME COLUMN
# ------------------------------------------------------------
# Session windows REQUIRE event time
lines = lines.withColumn("event_time", current_timestamp())

# ------------------------------------------------------------
# 5️⃣ SPLIT LINES INTO WORDS
# ------------------------------------------------------------
words = lines.select(
    explode(split(lines.value, " ")).alias("word"),
    "event_time"
)

# ------------------------------------------------------------
# 6️⃣ APPLY SESSION WINDOW
# ------------------------------------------------------------
# Session gap = 10 seconds
# If no events for 10 seconds → session ends

session_counts = words.groupBy(
    session_window("event_time", "10 seconds"),
    "word"
).count()

# ------------------------------------------------------------
# 7️⃣ WRITE RESULTS TO CONSOLE
# ------------------------------------------------------------
query = session_counts.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .start()

print("✅ Session window streaming started")

# ------------------------------------------------------------
# 8️⃣ KEEP STREAMING RUNNING
# ------------------------------------------------------------
try:
    query.awaitTermination()

except KeyboardInterrupt:
    print("\n🛑 Stopping session window streaming")
    query.stop()
    spark.stop()
    print("✅ Spark stopped cleanly")



# Terminal 1 – Send Data

# Type slowly to see sessions clearly:

# hello spark
# spark streaming


# (wait 10+ seconds)

# hello again