"""
Spark Structured Streaming – Tumbling Window Word Count
=======================================================

Purpose:
- Read real-time text data from a TCP socket (localhost:9999)
- Split incoming lines into words
- Group words into fixed, non-overlapping time windows
- Count word occurrences per window
- Continuously display results in the console

Window Configuration:
- Tumbling Window
- Window Duration : 10 seconds
- No overlap between windows
"""

# ------------------------------------------------------------
# 1️⃣ WINDOWS + SPARK ENVIRONMENT SETUP (MANDATORY)
# ------------------------------------------------------------
# Spark runs on the JVM, so Python must know where Spark,
# Hadoop binaries, and Java are installed.

import os
import findspark

# ✅ SET THESE PATHS CORRECTLY (AS YOU REQUESTED)
os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Initialize Spark so PySpark can locate Spark binaries
findspark.init(os.environ["SPARK_HOME"])


# ------------------------------------------------------------
# 2️⃣ IMPORT REQUIRED LIBRARIES
# ------------------------------------------------------------
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split, current_timestamp, window


# ------------------------------------------------------------
# 3️⃣ CREATE SPARK SESSION
# ------------------------------------------------------------
# local[*] → Use all available CPU cores
# SparkSession is the entry point for Structured Streaming

spark = SparkSession.builder \
    .appName("TumblingWindowWordCount") \
    .master("local[*]") \
    .getOrCreate()

# Reduce log noise for clarity
spark.sparkContext.setLogLevel("WARN")

print("✅ Spark started successfully")
print("👉 Waiting for streaming data from socket...")


# ------------------------------------------------------------
# 4️⃣ READ STREAMING DATA FROM SOCKET
# ------------------------------------------------------------
# Spark continuously listens on the given host and port.
# Each line received is treated as one streaming event.

lines = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()


# ------------------------------------------------------------
# 5️⃣ ADD EVENT-TIME COLUMN
# ------------------------------------------------------------
# Window operations require a timestamp column.
# current_timestamp() assigns the time Spark processes the event.

lines = lines.withColumn("event_time", current_timestamp())


# ------------------------------------------------------------
# 6️⃣ SPLIT LINES INTO WORDS
# ------------------------------------------------------------
# split()  → breaks a line into words
# explode() → converts the list of words into multiple rows

words = lines.select(
    explode(split(lines.value, " ")).alias("word"),
    "event_time"
)


# ------------------------------------------------------------
# 7️⃣ APPLY TUMBLING WINDOW AGGREGATION
# ------------------------------------------------------------
# Tumbling Window:
# - Fixed window size: 10 seconds
# - No overlap
# - Each word belongs to exactly ONE window

tumbling_counts = words.groupBy(
    window("event_time", "10 seconds"),
    "word"
).count()


# ------------------------------------------------------------
# 8️⃣ WRITE STREAMING RESULTS TO CONSOLE
# ------------------------------------------------------------
# outputMode = "complete"
# - Required for aggregations
# - Prints the full result table every trigger

query = tumbling_counts.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .start()

print("✅ Tumbling window streaming query started")


# ------------------------------------------------------------
# 9️⃣ KEEP STREAMING APPLICATION RUNNING
# ------------------------------------------------------------
# Streaming runs continuously until manually stopped.

try:
    query.awaitTermination()
except KeyboardInterrupt:
    print("\n🛑 Stopping streaming query")
    query.stop()
    spark.stop()
    print("✅ Spark stopped cleanly")


# hello spark
# hello streaming
# spark window
