"""
Spark Structured Streaming – Hopping Window Word Count
======================================================

Purpose:
- Reads real-time text data from a TCP socket
- Splits incoming text into words
- Applies a hopping (sliding) time window
- Counts words per window
- Displays results continuously

Window Configuration:
- Window Duration : 20 seconds
- Slide Interval  : 5 seconds (overlapping windows)
"""

# ------------------------------------------------------------
# 1️⃣ WINDOWS + SPARK ENVIRONMENT SETUP (MANDATORY)
# ------------------------------------------------------------
import os
import findspark

# ✅ SET THESE PATHS CORRECTLY
os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Initialize Spark so PySpark can find Spark binaries
findspark.init(os.environ["SPARK_HOME"])


# ------------------------------------------------------------
# 2️⃣ IMPORT SPARK LIBRARIES
# ------------------------------------------------------------
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split, current_timestamp, window


# ------------------------------------------------------------
# 3️⃣ CREATE SPARK SESSION
# ------------------------------------------------------------
spark = SparkSession.builder \
    .appName("HoppingWindowWordCount") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

print("✅ Spark started successfully")
print("👉 Waiting for streaming data from socket...")


# ------------------------------------------------------------
# 4️⃣ READ STREAMING DATA FROM SOCKET
# ------------------------------------------------------------
lines = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()


# ------------------------------------------------------------
# 5️⃣ ADD EVENT-TIME COLUMN
# ------------------------------------------------------------
lines = lines.withColumn("event_time", current_timestamp())


# ------------------------------------------------------------
# 6️⃣ SPLIT LINES INTO WORDS
# ------------------------------------------------------------
words = lines.select(
    explode(split(lines.value, " ")).alias("word"),
    "event_time"
)


# ------------------------------------------------------------
# 7️⃣ APPLY HOPPING WINDOW AGGREGATION
# ------------------------------------------------------------
windowed_counts = words \
    .withWatermark("event_time", "30 seconds") \
    .groupBy(
        window("event_time", "20 seconds", "5 seconds"),
        "word"
    ) \
    .count()


# ------------------------------------------------------------
# 8️⃣ WRITE STREAMING RESULTS TO CONSOLE
# ------------------------------------------------------------
query = windowed_counts.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .start()

print("✅ Hopping window streaming query started")


# ------------------------------------------------------------
# 9️⃣ KEEP STREAMING RUNNING
# ------------------------------------------------------------
try:
    query.awaitTermination()
except KeyboardInterrupt:
    print("\n🛑 Stopping streaming query")
    query.stop()
    spark.stop()
    print("✅ Spark stopped cleanly")


# Start Socket Server

# SEND DATA (Terminal 1)

# Type:

# hello spark
# hello streaming
# spark window