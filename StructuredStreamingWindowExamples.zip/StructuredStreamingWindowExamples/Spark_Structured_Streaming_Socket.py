import os
import sys
import types
import time

# ================================
# Step 1: Environment Setup
# ================================
os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Update PATH
os.environ["PATH"] = (
    os.path.join(os.environ["JAVA_HOME"], "bin") + ";" +
    os.path.join(os.environ["HADOOP_HOME"], "bin") + ";" +
    os.environ["PATH"]
)

# Add PySpark and Py4J to sys.path
py_lib = os.path.join(os.environ["SPARK_HOME"], "python", "lib")
pyspark_zip = os.path.join(py_lib, "pyspark.zip")
py4j_zip = None
for name in os.listdir(py_lib):
    if name.startswith("py4j") and name.endswith(".zip"):
        py4j_zip = os.path.join(py_lib, name)
        break
sys.path.insert(0, pyspark_zip)
if py4j_zip:
    sys.path.insert(0, py4j_zip)

# Enable Kafka support (optional)
os.environ['PYSPARK_SUBMIT_ARGS'] = (
    "--packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.4 pyspark-shell"
)

print("✅ Environment variables set")
print("SPARK_HOME:", os.environ["SPARK_HOME"])
print("HADOOP_HOME:", os.environ["HADOOP_HOME"])
print("JAVA_HOME:", os.environ["JAVA_HOME"])

# ================================
# Step 2: SparkSession Setup
# ================================
try:
    from pyspark.sql import SparkSession
except ModuleNotFoundError as e:
    if "typing.io" in str(e):
        import typing
        shim = types.ModuleType("typing.io")
        shim.BinaryIO = getattr(typing, "BinaryIO", None)
        sys.modules["typing.io"] = shim
        from pyspark.sql import SparkSession
    else:
        raise

from pyspark.sql.functions import explode, split

spark = SparkSession.builder \
    .appName("StructuredNetworkWordCount") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
print("✅ SparkSession created. Version:", spark.version)

# ================================
# Step 3: Streaming Source
# ================================
# Run in another terminal before starting this script:
#   nc -lk 9999   (Linux/Mac)
#   ncat -l -p 9999 --keep-open (Windows with Ncat from Nmap)
lines = spark \
    .readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

# ================================
# Step 4: Transformations
# ================================
words = lines.select(
   explode(split(lines.value, " ")).alias("word")
)

wordCounts = words.groupBy("word").count()

# ================================
# Step 5: Streaming Query
# ================================
query = wordCounts \
    .writeStream \
    .queryName("agg1") \
    .outputMode("complete") \
    .format("memory") \
    .start()

print("✅ Query started. Streaming from socket localhost:9999")

# ================================
# Step 6: Live Output Loop
# ================================
try:
    while True:
        print("\n=== Current Word Counts ===")
        spark.sql("SELECT * FROM agg1").show()
        time.sleep(2)
except KeyboardInterrupt:
    print("Stopping query...")
    query.stop()
    spark.stop()




# ncat -l -p 9999 --keep-open
#ncat localhost 9999
# hello world
# hello spark
