# ============================================================
# Spark Structured Streaming – JSON File Source (FILE STREAMING)
# ============================================================

"""
PURPOSE
-------
This program demonstrates Spark Structured Streaming using a FILE source.

Although files are batch-based, Spark treats NEWLY ARRIVING FILES
as a continuous data stream.

Each new JSON file:
- is processed once
- becomes part of a micro-batch
- updates aggregation results in real time

PIPELINE
--------
JSON files (directory)
        ↓
Spark Structured Streaming (micro-batches)
        ↓
Schema-based parsing
        ↓
Stateful aggregation (groupBy)
        ↓
In-memory result table
        ↓
Console output
"""

# ------------------------------------------------------------
# 1️⃣ ENVIRONMENT INITIALIZATION (WINDOWS)
# ------------------------------------------------------------
# On Windows, Spark does not auto-detect installations.
# We must explicitly tell Python where Spark, Hadoop, and Java live.

import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

# Makes PySpark available in the current Python process
findspark.init(os.environ["SPARK_HOME"])


# ------------------------------------------------------------
# 2️⃣ CREATE SPARK SESSION
# ------------------------------------------------------------
# SparkSession is the ENTRY POINT for all Spark functionality.
# Structured Streaming runs as a long-lived Spark application.

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
import time

spark = SparkSession.builder \
    .appName("StructuredStreaming_JSON_FileSource") \
    .master("local[*]") \
    .getOrCreate()

# Reduce log noise so output is readable
spark.sparkContext.setLogLevel("WARN")

print("✅ Spark started successfully")


# ------------------------------------------------------------
# 3️⃣ DEFINE EXPLICIT SCHEMA (MANDATORY)
# ------------------------------------------------------------
# File-based streaming DOES NOT support schema inference.
# Spark must know the structure BEFORE reading any files.

schema = StructType([
    StructField("id", StringType(), True),
    StructField("first_name", StringType(), True),
    StructField("last_name", StringType(), True),
    StructField("email", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("ip_address", StringType(), True)
])


# ------------------------------------------------------------
# 4️⃣ INPUT DIRECTORY AS STREAMING SOURCE
# ------------------------------------------------------------
# Spark continuously MONITORS this directory.
# Every NEW file added is treated as a streaming event.

inputPath = r"C:\spark-streaming-practice\20_jsons"


# ------------------------------------------------------------
# 5️⃣ CREATE STREAMING DATAFRAME
# ------------------------------------------------------------
# readStream tells Spark this is NOT a batch job.
# maxFilesPerTrigger = 1 simulates real-time arrival.

streamingDF = (
    spark.readStream
         .schema(schema)                 # Apply predefined schema
         .option("maxFilesPerTrigger", 1) # One file per micro-batch
         .json(inputPath)
)

# Defensive data cleaning
# Removes rows with missing fields
streamingDF = streamingDF.dropna()


# ------------------------------------------------------------
# 6️⃣ STATEFUL REAL-TIME AGGREGATION
# ------------------------------------------------------------
# This is a STATEFUL operation.
# Spark maintains running counts across micro-batches.

gender_counts = streamingDF.groupBy("gender").count()


# ------------------------------------------------------------
# 7️⃣ WRITE STREAM TO MEMORY SINK
# ------------------------------------------------------------
# Memory sink stores results INSIDE Spark as a temporary table.
# outputMode = "complete" is REQUIRED for aggregations.

query = (
    gender_counts.writeStream
        .queryName("gender_counts")  # Acts like a SQL table name
        .outputMode("complete")      # Recompute full result each batch
        .format("memory")            # Store results in Spark memory
        .start()
)

print("✅ Streaming started (JSON files → Spark Structured Streaming)")


# ------------------------------------------------------------
# 8️⃣ CONTINUOUSLY DISPLAY RESULTS
# ------------------------------------------------------------
# Streaming runs asynchronously.
# This loop simply queries the in-memory table repeatedly.

try:
    while True:
        print("\n===== CURRENT STREAM OUTPUT =====")
        spark.sql("SELECT * FROM gender_counts").show(truncate=False)
        time.sleep(2)

except KeyboardInterrupt:
    print("\n🛑 Stopping streaming job")
    query.stop()
    spark.stop()
    print("✅ Spark stopped cleanly")
