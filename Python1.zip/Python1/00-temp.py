# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 17:21:27 2019

@author: Kanakaraju
"""

from dateutil import parser

print(parser.parse('01-01-2019'))      

        