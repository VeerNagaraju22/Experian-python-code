# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 16:57:33 2019

@author: Kanakaraju
"""

import module1

print("==== module2.py ====")
 
module1.fun()
 
print("module1.__name__ : ", module1.__name__)
print("module2.__name__  = ", __name__)