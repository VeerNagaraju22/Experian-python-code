# str1 = 'welcome to python.'
#
# print(str1[1:5])


# text="hello world"
# print(text.find("o",5))
# print(text.find("h",2))
#
# print(text.index("o",5))
# print(text.index("h",2))
#
# tuple1 = (1,'Veer',876887.99)
# print(type(tuple1))
# list1 = [1,'Veer',876887.99]
# print(type(list1))
# set1 = {1,'Veer',876887.99}
# print(type(set1))
d3 = {1: 'one', '2':'two', 3.5:'three', 4:4}
# for k,v in d3.items() :
#     print (k, v)
# d4 = d3.get('5', None)
# d5 = d3.get(4, None)
# d3.get('5', 'key 5 not found')
# print(d5)
#
# data = {"student": {"name": "Ram", "marks": {"math": 90, "science": 85}}}
# # Access the value of "science" marks
# science_marks = data["student"]["marks"]["science"]
# print(science_marks)

# r1 = range(10)
# r2 = range(1,10)
# r3 = range(10,1,-2)
# print(r1)
# print(type(r1))
#
# for i in r3:
#     print(i)
import os
import sys
fh = open("anthem1.txt")

fh.tell()  # tel me where the file pointer is
fh.read(7) # read 7 chars from the current file pointer

fh.tell()

fh.read() # read the entire file from the current file pointer

fh.tell()

fh.seek(4)  # move the file pointer to 4

fh.read(15)