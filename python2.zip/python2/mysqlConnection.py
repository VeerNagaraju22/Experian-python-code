# -*- coding: utf-8 -*-
"""
Created on Tue May  6 17:53:22 2025

@author: Tekcrux
"""

import mysql.connector

# Establish the connection to the database
try:
    connection = mysql.connector.connect(
        host="localhost",  # Replace with your MySQL server hostname
        user="root",  # Replace with your MySQL username
        password="root",  # Replace with your MySQL password
        database="company_db"  # Replace with the database you want to connect to
    )

    if connection.is_connected():
        print("Successfully connected to MySQL database")

        # Create a cursor object using the connection
        cursor = connection.cursor()

        # Example query to fetch data from a table
        query = "SELECT * FROM employees;"  # Replace 'users' with your table name
        cursor.execute(query)

        # Fetch and print the results
        results = cursor.fetchall()
        for row in results:
            print(row)

except mysql.connector.Error as err:
    print(f"Error: {err}")
finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL connection is closed")


