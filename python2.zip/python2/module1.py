# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 16:55:18 2019

@author: Kanakaraju
"""

print("==== module1.py ====")
 
def fun():
    print("running fun() method in module1.py")
 
if __name__ == "__main__":
    print("Running as main program")
    print("__name__  = ", __name__)
    fun()
    
person1 = {
  "name": "Raju",
  "age": 40,
  "country": "India"
}