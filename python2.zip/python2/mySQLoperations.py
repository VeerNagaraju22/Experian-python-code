# -*- coding: utf-8 -*-
"""
Created on Fri May  9 10:40:27 2025

@author: Tekcrux
"""
import mysql.connector
from mysql.connector import Error

def create_connection():
    try:
        # Establish a connection to the MySQL database
        connection = mysql.connector.connect(
            host="localhost",       # Replace with your MySQL host
            user="root",            # Replace with your MySQL username
            password="root",        # Replace with your MySQL password
            database="company_db"   # Replace with your MySQL database name
        )
        if connection.is_connected():
            print("Successfully connected to MySQL")
            return connection
    except Error as e:
        print("Error while connecting to MySQL", e)
        return None

def create_table(connection):
    try:
        cursor = connection.cursor()
        # Create a table
        query = """CREATE TABLE IF NOT EXISTS csgi_employees1 (
                        emp_id INT PRIMARY KEY,
                        name VARCHAR(50),
                        email VARCHAR(100)
                    );"""
        cursor.execute(query)
        print("Table 'employees' created successfully.")
    except Error as e:
        print("Error creating table:", e)

def insert_data(connection):
    try:
        cursor = connection.cursor()
        # Insert data into the table
        query = "INSERT INTO csgi_employees1 (emp_id, name, email) VALUES (%s, %s, %s)"
        values = [(1, 'John Doe', 'john.doe@example.com'),
                  (2, 'Jane Smith', 'jane.smith@example.com'),
                  (3, 'Veer Nagaraju', 'bigdataminds@gmail.com')]
        cursor.executemany(query, values)
        connection.commit()
        print("Data inserted successfully.")
    except Error as e:
        print("Error inserting data:", e)

def update_data(connection):
    try:
        cursor = connection.cursor()
        # Update data in the table
        query = "UPDATE csgi_employees1 SET email = %s WHERE emp_id = %s"
        values = ('john.doe@newdomain.com', 1)
        cursor.execute(query, values)
        connection.commit()
        print("Data updated successfully.")
    except Error as e:
        print("Error updating data:", e)

def delete_data(connection):
    try:
        cursor = connection.cursor()
        # Delete data from the table
        query = "DELETE FROM csgi_employees1 WHERE emp_id = %s"
        value = (2,)
        cursor.execute(query, value)
        connection.commit()
        print("Data deleted successfully.")
    except Error as e:
        print("Error deleting data:", e)

def fetch_data(connection):
    try:
        cursor = connection.cursor()
        # Fetch data from the table
        cursor.execute("SELECT * FROM csgi_employees1")
        rows = cursor.fetchall()
        for row in rows:
            print(row)
    except Error as e:
        print("Error fetching data:", e)

def close_connection(connection):
    if connection.is_connected():
        connection.close()
        print("Connection closed.")

# Main function to perform operations
if __name__ == "__main__":
    # Create a connection to the database
    connection = create_connection()

    if connection:
        create_table(connection)    # Create table if not exists
        insert_data(connection)     # Insert data
        update_data(connection)     # Update data
        delete_data(connection)     # Delete data
        fetch_data(connection)      # Fetch and display data
        close_connection(connection)  # Close the connection

