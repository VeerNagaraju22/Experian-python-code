import mysql.connector

# Establish the connection to the database
try:
    connection = mysql.connector.connect(
        host="localhost",  # Replace with your MySQL server hostname
        user="root",       # Replace with your MySQL username
        password="root",   # Replace with your MySQL password
        database="employeeinfo"  # Replace with the database you want to connect to
    )

    if connection.is_connected():
        print("Successfully connected to MySQL database")

        # Create a cursor object using the connection
        cursor = connection.cursor()

        # Modified query to fetch salary column as well
        query = "SELECT eid,ename,esal FROM employee;"
        cursor.execute(query)

        # Fetch and print the results
        results = cursor.fetchall()
        sum = 0
        for row in results:
            eid, ename, esal = row
            sum += esal
            print(f"ID: {eid}, eName: {ename}, Salary: {esal}")
        print("Sum of Salary: ", sum)

except mysql.connector.Error as err:
    print(f"Error: {err}")
finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL connection is closed")
