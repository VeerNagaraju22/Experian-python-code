# ============================================================
# Spark Streaming (DStreams) – Core Transformations Demo
# ============================================================

"""
PURPOSE
-------
This program demonstrates the most important DStream transformations:

- map
- filter
- flatMap
- reduceByKey

DATA SOURCE
-----------
Text data is read from a TCP socket (localhost:9999)

ARCHITECTURE
------------
Socket Producer
      ↓
Spark Streaming (DStreams)
      ↓
Transformations
      ↓
Console Output

NOTE
----
This uses Spark Streaming (DStreams) – legacy API.
Used mainly for learning and legacy systems.
"""

# ------------------------------------------------------------
# 1️⃣ ENVIRONMENT SETUP (WINDOWS)
# ------------------------------------------------------------
import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

findspark.init(os.environ["SPARK_HOME"])


# ------------------------------------------------------------
# 2️⃣ IMPORT SPARK STREAMING MODULES
# ------------------------------------------------------------
from pyspark import SparkContext
from pyspark.streaming import StreamingContext


# ------------------------------------------------------------
# 3️⃣ CREATE SPARK CONTEXT
# ------------------------------------------------------------
# local[2] → one thread for receiving data, one for processing
sc = SparkContext(master="local[2]", appName="DStreamTransformations")

# Batch interval = 5 seconds
ssc = StreamingContext(sc, 5)

print("✅ Spark Streaming started")


# ------------------------------------------------------------
# 4️⃣ CREATE SOCKET STREAM (SOURCE)
# ------------------------------------------------------------
# Make sure socket server is running on port 9999
lines = ssc.socketTextStream("localhost", 9999)


# ------------------------------------------------------------
# 5️⃣ TRANSFORMATION 1: flatMap
# ------------------------------------------------------------
# Splits each line into multiple words
words = lines.flatMap(lambda line: line.split(" "))


# ------------------------------------------------------------
# 6️⃣ TRANSFORMATION 2: map
# ------------------------------------------------------------
# Convert each word to (word, 1)
word_pairs = words.map(lambda word: (word.lower(), 1))


# ------------------------------------------------------------
# 7️⃣ TRANSFORMATION 3: filter
# ------------------------------------------------------------
# Keep only words with length > 3
filtered_words = word_pairs.filter(lambda pair: len(pair[0]) > 3)


# ------------------------------------------------------------
# 8️⃣ TRANSFORMATION 4: reduceByKey
# ------------------------------------------------------------
# Count words per batch
word_counts = filtered_words.reduceByKey(lambda a, b: a + b)


# ------------------------------------------------------------
# 9️⃣ OUTPUT RESULTS
# ------------------------------------------------------------
word_counts.pprint()


# ------------------------------------------------------------
# 🔟 START STREAMING
# ------------------------------------------------------------
ssc.start()
ssc.awaitTermination()



# -----------------------------
# In Terminal
# -----------------------------


# Terminal 1
# Open Ncat terminal on port 9999:

# ncat -l -p 9999 --keep-open


# Terminal 2 – Run Spark Streaming
# python spark_dstream_transformations.py

# Terminal 1 – Send Data
# hello spark streaming
# this is awesome
# spark spark streaming
