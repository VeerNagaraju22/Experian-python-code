# ============================================================
# Spark Streaming (DStreams) – Stateful Network Word Count
# ============================================================

"""
PURPOSE
-------
This program demonstrates Spark's *legacy* streaming API (DStreams).

It reads text data from a TCP socket, splits it into words,
and maintains a RUNNING COUNT of words across batches using state.

IMPORTANT
---------
- This uses Spark Streaming (DStreams), NOT Structured Streaming
- updateStateByKey requires checkpointing
- Used mainly for learning & legacy systems
"""

# ------------------------------------------------------------
# 1️⃣ ENVIRONMENT SETUP (WINDOWS)
# ------------------------------------------------------------
import os
import findspark

os.environ["SPARK_HOME"] = r"C:\spark-3.3.4-bin-hadoop2"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-1.8"

findspark.init(os.environ["SPARK_HOME"])


# ------------------------------------------------------------
# 2️⃣ IMPORT SPARK STREAMING MODULES
# ------------------------------------------------------------
from pyspark import SparkContext
from pyspark.streaming import StreamingContext


# ------------------------------------------------------------
# 3️⃣ CREATE SPARK CONTEXT
# ------------------------------------------------------------
# local[2] → one thread for receiver, one for processing
sc = SparkContext(master="local[2]", appName="StatefulNetworkWordCount")

# Batch interval = 5 seconds
ssc = StreamingContext(sc, 5)

# REQUIRED for stateful operations
ssc.checkpoint("checkpoint")

print("✅ Spark Streaming Context started")


# ------------------------------------------------------------
# 4️⃣ CREATE SOCKET STREAM (SOURCE)
# ------------------------------------------------------------
# Make sure socket server (nc / ncat) is running on this port
lines = ssc.socketTextStream("localhost", 9999)


# ------------------------------------------------------------
# 5️⃣ SPLIT LINES INTO WORDS
# ------------------------------------------------------------
words = lines.flatMap(lambda line: line.split(" "))


# ------------------------------------------------------------
# 6️⃣ MAP WORDS TO (word, 1)
# ------------------------------------------------------------
pairs = words.map(lambda word: (word, 1))


# ------------------------------------------------------------
# 7️⃣ DEFINE STATE UPDATE FUNCTION
# ------------------------------------------------------------
# new_values → values in current batch
# last_state → previous running total

def update_function(new_values, last_state):
    if last_state is None:
        last_state = 0
    return sum(new_values) + last_state


# ------------------------------------------------------------
# 8️⃣ OPTIONAL INITIAL STATE
# ------------------------------------------------------------
# Initial counts before streaming starts
initial_state = sc.parallelize([
    ("hello", 1),
    ("world", 1)
])


# ------------------------------------------------------------
# 9️⃣ APPLY updateStateByKey (STATEFUL TRANSFORMATION)
# ------------------------------------------------------------
running_counts = pairs.updateStateByKey(
    update_function,
    initialRDD=initial_state
)


# ------------------------------------------------------------
# 🔟 OUTPUT RESULTS
# ------------------------------------------------------------
# Prints running totals every batch
running_counts.pprint()


# ------------------------------------------------------------
# 1️⃣1️⃣ START STREAMING
# ------------------------------------------------------------
ssc.start()
ssc.awaitTermination()



# -----------------------------
# In Terminal
# -----------------------------

# Open Ncat terminal on port 9998:

# ncat -l -p 9999 --keep-open



# Type some words in the Ncat terminal:

# hello world
# hello spark