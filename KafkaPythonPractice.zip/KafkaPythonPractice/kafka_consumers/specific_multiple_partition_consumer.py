from kafka import KafkaConsumer, TopicPartition

# ============================================================
# 1️⃣ KAFKA CONNECTION CONFIGURATION
# ============================================================
# bootstrap_servers:
# - Initial broker(s) used to discover Kafka cluster metadata
#
# topic_name:
# - Kafka topic from which messages will be consumed
#
# partitions_to_consume:
# - Explicit list of partitions this consumer will read from
# - Manual assignment → NO consumer group rebalancing

bootstrap_servers = ['localhost:9092']
topic_name = 'mytopic'
partitions_to_consume = [0, 1]   # Consume only partition 0 and 1


# ============================================================
# 2️⃣ CREATE KAFKA CONSUMER (NO GROUP)
# ============================================================
# NOTE:
# - group_id is intentionally NOT provided
# - This disables Kafka's consumer group management
# - Offsets are NOT shared or coordinated with other consumers

consumer = KafkaConsumer(
    bootstrap_servers=bootstrap_servers,

    # Deserialize message key from bytes → string
    key_deserializer=lambda k: k.decode('utf-8') if k else None,

    # Deserialize message value from bytes → string
    value_deserializer=lambda v: v.decode('utf-8') if v else None,

    # Start from earliest offset if no committed offset exists
    auto_offset_reset='earliest',

    # Offset commits are managed manually (or not at all)
    enable_auto_commit=False,

    # Match broker API version
    api_version=(3, 6, 1)
)


# ============================================================
# 3️⃣ MANUAL PARTITION ASSIGNMENT
# ============================================================
# TopicPartition explicitly binds:
# - topic name
# - partition number
#
# consumer.assign():
# - Bypasses Kafka's rebalancing
# - This consumer will ONLY read from these partitions
# - No other consumer can steal these partitions automatically

assigned_partitions = [
    TopicPartition(topic_name, pid)
    for pid in partitions_to_consume
]

consumer.assign(assigned_partitions)

print(
    f"✅ Consumer manually assigned to partitions "
    f"{partitions_to_consume} of topic '{topic_name}'\n"
)


# ============================================================
# 4️⃣ POLL AND PROCESS MESSAGES
# ============================================================
# poll():
# - Fetches messages from Kafka
# - Returns a dictionary:
#     { TopicPartition : [ConsumerRecord, ...] }
#
# timeout_ms:
# - Prevents blocking indefinitely

try:
    while True:
        records = consumer.poll(timeout_ms=1000)

        for tp, messages in records.items():
            for msg in messages:
                print(f"📦 Topic      : {msg.topic}")
                print(f"📍 Partition  : {msg.partition}")
                print(f"📌 Offset     : {msg.offset}")
                print(f"🔑 Key        : {msg.key}")
                print(f"📝 Value      : {msg.value}")
                print("-" * 60)

except KeyboardInterrupt:
    # Graceful shutdown on Ctrl+C
    print("\n🛑 Consumer interrupted by user")

finally:
    # ============================================================
    # 5️⃣ CLEAN SHUTDOWN
    # ============================================================
    # Always close consumer to:
    # - Release network connections
    # - Leave clean client state

    consumer.close()
    print("✅ Consumer closed cleanly")
