"""
Kafka Consumer – Professional Example
=====================================

Purpose:
- Consumes messages from a Kafka topic
- Part of a Kafka consumer group
- Automatically balances partitions across consumers
- Prints message metadata (partition, offset, key, value)

Use Case:
- Learning Kafka consumers
- Understanding consumer groups and partition assignment
- Debugging / monitoring message flow

Architecture:
Kafka Topic → Consumer Group → Consumer Instance
"""

from kafka import KafkaConsumer
import socket

# --------------------------------------------------
# 1️⃣ KAFKA CONNECTION CONFIGURATION
# --------------------------------------------------
# Address of Kafka broker(s)
bootstrap_servers = ['localhost:9092']

# Kafka topic to subscribe to
topic_name = 'mytopicnew'

# Consumer group ID
# All consumers with the same group_id share partitions
group_id = 'student-group'

# Get machine/host name
# Helpful to identify which consumer instance is processing data
consumer_name = socket.gethostname()


# --------------------------------------------------
# 2️⃣ CREATE KAFKA CONSUMER
# --------------------------------------------------
consumer = KafkaConsumer(
    topic_name,

    # Kafka broker(s) to connect to
    bootstrap_servers=bootstrap_servers,

    # Consumer group name (enables partition balancing)
    group_id=group_id,

    # Automatically commit offsets after processing
    enable_auto_commit=True,

    # If no offset is found for this group,
    # start reading from the earliest message
    auto_offset_reset='earliest',

    # Deserialize message key from bytes → string
    key_deserializer=lambda k: k.decode('utf-8') if k else None,

    # Deserialize message value from bytes → string
    value_deserializer=lambda v: v.decode('utf-8') if v else None,

    # Kafka broker API version (match with your Kafka version)
    api_version=(3, 6, 1)
)

print(f"✅ [{consumer_name}] Joined consumer group '{group_id}'")
print("🎯 Waiting for messages...\n")


# --------------------------------------------------
# 3️⃣ POLL AND PROCESS MESSAGES
# --------------------------------------------------
try:
    while True:
        # poll() fetches messages from Kafka
        # timeout_ms prevents blocking forever
        records = consumer.poll(timeout_ms=1000)

        # records is a dictionary:
        # { TopicPartition : [ConsumerRecord, ...] }
        for partition_records in records.values():
            for msg in partition_records:
                print(f"[{consumer_name}] 📦 Partition: {msg.partition}")
                print(f"📍 Offset: {msg.offset}")
                print(f"🔑 Key: {msg.key}")
                print(f"📨 Value: {msg.value}")
                print("-" * 50)

except KeyboardInterrupt:
    # Graceful shutdown on Ctrl+C
    print("\n🛑 Consumer interrupted by user")

finally:
    # --------------------------------------------------
    # 4️⃣ CLEAN SHUTDOWN
    # --------------------------------------------------
    consumer.close()
    print(f"✅ [{consumer_name}] Consumer closed cleanly")
