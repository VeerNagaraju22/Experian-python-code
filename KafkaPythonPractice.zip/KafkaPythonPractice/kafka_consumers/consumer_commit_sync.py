from kafka import KafkaConsumer

# ============================================================
# Kafka Consumer – Manual Offset Management (Python)
# ============================================================
# Purpose:
# This script consumes messages from an Apache Kafka topic
# using a consumer group with manual offset control.
#
# Key characteristics:
# - Reads messages from the beginning of the topic (for new groups)
# - Processes records in polling cycles
# - Commits offsets explicitly after processing
#
# This pattern is commonly used when message processing
# must be completed successfully before offsets are committed.
# ============================================================


# ------------------------------------------------------------
# Kafka Configuration
# ------------------------------------------------------------
# Kafka broker address.
# In a local Kafka setup, the broker typically listens
# on localhost:9092.
bootstrap_servers = ['localhost:9092']

# Target Kafka topic to consume messages from.
topic_name = 'mytopic'

# Consumer group identifier.
# A new group ID ensures offsets start from the beginning
# when auto_offset_reset is set to 'earliest'.
group_id = 'mygroup-new-test'


# ------------------------------------------------------------
# KafkaConsumer Initialization
# ------------------------------------------------------------
# The KafkaConsumer instance is responsible for:
# - Connecting to Kafka brokers
# - Joining the specified consumer group
# - Fetching records from assigned partitions
# - Managing offset commits
consumer = KafkaConsumer(
    # Topic subscription
    topic_name,

    # Kafka broker connection details
    bootstrap_servers=bootstrap_servers,

    # Consumer group identifier
    group_id=group_id,

    # Deserialize message keys from bytes to string
    # Handles null keys safely
    key_deserializer=lambda k: k.decode('utf-8') if k else None,

    # Optional value deserializer (commented for flexibility)
    # value_deserializer=lambda v: v.decode('utf-8') if v else None,

    # Disable automatic offset commits to allow
    # explicit, application-controlled offset management
    enable_auto_commit=False,

    # Offset reset policy for new consumer groups.
    # Starts reading from the earliest available offset.
    auto_offset_reset='earliest',

    # Explicit Kafka API version for compatibility
    api_version=(3, 6, 1)
)

print(f"✅ Subscribed to topic: {topic_name}")
print("🎯 Consumer started. Waiting for messages... (Ctrl+C to stop)\n")


# ------------------------------------------------------------
# Polling and Message Processing Loop
# ------------------------------------------------------------
# Continuously polls Kafka for new messages.
# Messages are processed record-by-record, and offsets
# are committed only after successful processing.
try:
    while True:
        # Poll Kafka for available records.
        # Returns a dictionary:
        # { TopicPartition : [ConsumerRecord, ...] }
        records = consumer.poll(timeout_ms=1000)

        # Iterate over partitions and their records
        for tp, messages in records.items():
            for record in messages:
                # Log message metadata and payload
                print(
                    f"📦 Topic: {record.topic}, "
                    f"Partition: {record.partition}, "
                    f"Offset: {record.offset}"
                )
                print(f"🔑 Key: {record.key}, 📝 Value: {record.value}")
                print("-" * 60)

        # ----------------------------------------------------
        # Manual Offset Commit
        # ----------------------------------------------------
        # Commits offsets synchronously after message
        # processing completes, ensuring at-least-once delivery.
        try:
            consumer.commit()
        except Exception as e:
            print(f"❌ Offset commit failed: {e}")


# ------------------------------------------------------------
# Graceful Shutdown Handling
# ------------------------------------------------------------
# Allows the consumer to exit cleanly when interrupted
# by the user (Ctrl+C).
except KeyboardInterrupt:
    print("\n🛑 Consumer stopped by user.")

finally:
    # Close the consumer and release network resources
    consumer.close()
    print("✅ Consumer closed cleanly.")
