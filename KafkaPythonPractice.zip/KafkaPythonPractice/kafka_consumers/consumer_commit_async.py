from kafka import KafkaConsumer
from kafka.errors import KafkaError
import time

# ============================================================
# 1️⃣ KAFKA CONSUMER CONFIGURATION
# ============================================================
# bootstrap_servers : Kafka broker address(es)
# topic_name        : Topic to consume messages from
# group_id          : Consumer group identifier
#
# All consumers using the same group_id will:
# - Share partitions
# - Load-balance message consumption
# - Maintain offsets together

bootstrap_servers = ['localhost:9092']
topic_name = 'mytopic'
group_id = 'mygroup1'


# ============================================================
# 2️⃣ CREATE KAFKA CONSUMER INSTANCE
# ============================================================
# Key design choices explained:
#
# enable_auto_commit = False
#   → We control when offsets are committed (manual control)
#
# auto_offset_reset = 'earliest'
#   → If this group has no committed offset, start from beginning
#
# key_deserializer / value_deserializer
#   → Kafka sends bytes → convert to string for readability
#
# api_version
#   → Ensures compatibility with your Kafka broker version

consumer = KafkaConsumer(
    topic_name,
    bootstrap_servers=bootstrap_servers,
    group_id=group_id,
    enable_auto_commit=False,          # Manual offset control
    auto_offset_reset='earliest',
    key_deserializer=lambda k: k.decode('utf-8') if k else None,
    value_deserializer=lambda v: v.decode('utf-8') if v else None,
    api_version=(3, 6, 1)
)

print("✅ Kafka Consumer started (manual offset management)\n")


# ============================================================
# 3️⃣ POLL LOOP – FETCH AND PROCESS MESSAGES
# ============================================================
# poll():
# - Fetches messages from Kafka broker
# - Returns a dictionary:
#   { TopicPartition : [ConsumerRecord, ...] }
#
# timeout_ms prevents blocking forever

try:
    while True:
        records = consumer.poll(timeout_ms=1000)

        # If no messages are available
        if not records:
            print("⏳ Waiting for messages...")
            time.sleep(1)
            continue

        # Iterate through partitions and their messages
        for topic_partition, messages in records.items():
            for msg in messages:
                print(f"📦 Topic     : {msg.topic}")
                print(f"📍 Partition : {msg.partition}")
                print(f"📌 Offset    : {msg.offset}")
                print(f"🔑 Key       : {msg.key}")
                print(f"📨 Value     : {msg.value}")
                print("-" * 50)

        # ----------------------------------------------------
        # 4️⃣ ASYNC OFFSET COMMIT
        # ----------------------------------------------------
        # Commits offsets AFTER successful message processing
        # Async commit:
        # - Non-blocking
        # - Faster
        # - Slight risk of commit failure (acceptable for most apps)

        consumer.commit_async()

except KeyboardInterrupt:
    print("\n🛑 Consumer stopped by user (Ctrl+C)")


# ============================================================
# 5️⃣ GRACEFUL SHUTDOWN & FINAL COMMIT
# ============================================================
# Final synchronous commit ensures:
# - No processed messages are re-read
# - Offsets are safely stored before shutdown

finally:
    try:
        consumer.commit()
        print("💾 Final offsets committed successfully")
    except Exception as e:
        print("⚠️ Error during final commit:", str(e))

    consumer.close()
    print("✅ Kafka consumer closed cleanly")
