broker.id=100
listeners=PLAINTEXT://:9092
advertised.listeners=PLAINTEXT://localhost:9092
log.dirs=/tmp/kafka-logs-100
zookeeper.connect=localhost:2181


pip install -r requirements.txt