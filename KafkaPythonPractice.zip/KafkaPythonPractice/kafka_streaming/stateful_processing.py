from kafka import KafkaConsumer, KafkaProducer
from collections import defaultdict
import json

"""
Kafka Stateful Stream Processor
===============================

Purpose:
- Consumes invoice events from a Kafka topic
- Maintains in-memory state (running counts per user)
- Publishes updated state to another Kafka topic

This mimics:
- Stateful stream processing
- Similar to Spark mapWithState / updateStateByKey
- Common pattern in Kafka Streams / Flink / Spark

Architecture:
Kafka Topic (invoices1)
        ↓
Stateful Consumer (this app)
        ↓
Kafka Topic (stateful-result)
"""


# ============================================================
# 1️⃣ SAFE JSON DESERIALIZER
# ============================================================
# Why needed:
# - Kafka messages are raw bytes
# - Bad / malformed JSON should not crash the consumer
# - This ensures fault tolerance

def safe_json_deserializer(value_bytes):
    try:
        return json.loads(value_bytes.decode('utf-8'))
    except Exception as e:
        print(f"⚠️ Skipping bad message: {value_bytes} | Error: {e}")
        return {}  # Return empty dict to keep pipeline alive


# ============================================================
# 2️⃣ KAFKA CONSUMER CONFIGURATION
# ============================================================
consumer = KafkaConsumer(
    'invoices1',                         # Source topic
    bootstrap_servers='localhost:9092',
    group_id='stateful-group',           # Enables consumer group behavior
    auto_offset_reset='earliest',        # Start from beginning if no offsets
    enable_auto_commit=True,             # Kafka manages offsets
    value_deserializer=safe_json_deserializer
)


# ============================================================
# 3️⃣ KAFKA PRODUCER CONFIGURATION
# ============================================================
# Sends aggregated results to another topic
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    key_serializer=lambda k: k.encode('utf-8'),
    value_serializer=lambda v: str(v).encode('utf-8')
)


# ============================================================
# 4️⃣ IN-MEMORY STATE STORE
# ============================================================
# Maintains running count per user
# This state lives only as long as the application runs
counts = defaultdict(int)

print("📊 Stateful Kafka consumer started...\n")


# ============================================================
# 5️⃣ STREAM PROCESSING LOOP
# ============================================================
for msg in consumer:
    invoice = msg.value

    # ⚠️ IMPORTANT CORRECTION:
    # Your producer sends user info as Kafka KEY, not inside JSON
    # So we must extract user from msg.key, not invoice["user"]

    user = msg.key.decode('utf-8') if msg.key else "Unknown"

    # Update state (running count)
    counts[user] += 1

    # Publish updated state downstream
    producer.send(
        topic='stateful-result',
        key=user,
        value=counts[user]
    )

    # Log current state
    print(f"📈 User: {user} → Total invoices processed: {counts[user]}")


#kafka-topics.bat --create --topic invoices1 --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

# kafka-console-producer.bat --topic invoices1 --bootstrap-server localhost:9092

# {"user": "alice", "amount": 100}
# {"user": "bob", "amount": 200}
# {"user": "alice", "amount": 300}

