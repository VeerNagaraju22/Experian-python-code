"""
Kafka Consumer – Word Count Result Reader
=========================================

Purpose:
- Consumes processed word-count results from a Kafka topic
- Part of a consumer group for scalable consumption
- Continuously listens and prints key-value pairs

Use Case:
- Reading output of a Kafka-based word count pipeline
- Verifying downstream processing results
- Learning Kafka consumer fundamentals

Architecture:
Kafka Topic (wordcount-result)
        ↓
Kafka Consumer Group (grp-1)
        ↓
Consumer Application (this script)
"""

from kafka import KafkaConsumer

# --------------------------------------------------
# 1️⃣ CREATE KAFKA CONSUMER
# --------------------------------------------------
consumer = KafkaConsumer(
    # Topic to consume messages from
    'wordcount-result',

    # Kafka broker(s)
    bootstrap_servers='localhost:9092',

    # Consumer group ID
    # Enables offset tracking and load balancing
    group_id='grp-1',

    # If no committed offset exists for this group,
    # start reading from the beginning of the topic
    auto_offset_reset='earliest',

    # Automatically commit offsets after messages are read
    enable_auto_commit=True,

    # Convert message key from bytes → string
    key_deserializer=lambda m: m.decode('utf-8') if m else None,

    # Convert message value from bytes → string
    # (word-count output is expected as plain text)
    value_deserializer=lambda m: m.decode('utf-8') if m else None
)

print("🔄 Listening to 'wordcount-result' topic...\n")

# --------------------------------------------------
# 2️⃣ CONTINUOUS MESSAGE CONSUMPTION LOOP
# --------------------------------------------------
try:
    # KafkaConsumer is iterable
    # Each iteration yields one ConsumerRecord
    for message in consumer:
        print(
            f"🔑 Key   : {message.key} | "
            f"📨 Value : {message.value}"
        )

except KeyboardInterrupt:
    # Graceful shutdown on Ctrl+C
    print("\n🛑 Consumer stopped by user.")

finally:
    # --------------------------------------------------
    # 3️⃣ CLEAN SHUTDOWN
    # --------------------------------------------------
    # Always close consumer to release resources
    consumer.close()
    print("✅ Kafka consumer closed cleanly.")
