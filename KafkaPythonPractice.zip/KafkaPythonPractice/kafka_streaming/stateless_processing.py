from kafka import KafkaConsumer, KafkaProducer
import json

"""
Kafka Stream Processor – Invoice Discount Enrichment
====================================================

Purpose:
- Consume invoice events from a Kafka topic
- Validate and parse JSON safely
- Apply simple business logic (discount calculation)
- Produce enriched events to another Kafka topic

This represents:
- Stateless stream processing
- Event validation + transformation
- Common Kafka ETL / stream enrichment pattern

Architecture:
Kafka Topic (invoices2)
        ↓
Stream Processor (this application)
        ↓
Kafka Topic (discounted-invoices)
"""


# ============================================================
# 1️⃣ KAFKA CONSUMER CONFIGURATION
# ============================================================
# NOTE:
# - We only decode bytes → string here
# - JSON parsing is handled explicitly later
# - This avoids crashes from malformed JSON

consumer = KafkaConsumer(
    'invoices1',                          # Source topic
    bootstrap_servers='localhost:9092',
    group_id='stateful-group',            # Consumer group
    auto_offset_reset='earliest',         # Read from beginning if no offset
    enable_auto_commit=True,              # Kafka manages offsets
    value_deserializer=lambda v: v.decode('utf-8') if v else None
)


# ============================================================
# 2️⃣ KAFKA PRODUCER CONFIGURATION
# ============================================================
# Sends processed (enriched) invoices downstream
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

print("📊 Invoice stream processor started...\n")


# ============================================================
# 3️⃣ STREAM PROCESSING LOOP
# ============================================================
for msg in consumer:
    raw_value = msg.value

    # --------------------------------------------------------
    # Step 1: Basic message validation
    # --------------------------------------------------------
    # Skip null, empty, or whitespace-only messages
    if not raw_value or not raw_value.strip():
        print("⚠️ Skipping empty or blank message.")
        continue

    try:
        # ----------------------------------------------------
        # Step 2: Parse JSON safely
        # ----------------------------------------------------
        invoice = json.loads(raw_value)

        # ----------------------------------------------------
        # Step 3: Schema validation
        # ----------------------------------------------------
        # Ensure required field exists before processing
        if 'invoiceAmount' not in invoice:
            print(f"⚠️ Invalid invoice (missing invoiceAmount): {invoice}")
            continue

        # ----------------------------------------------------
        # Step 4: Business logic (enrichment)
        # ----------------------------------------------------
        amount = invoice['invoiceAmount']

        # Simple rule-based discount
        invoice['discount'] = 5 if amount > 1000 else 0

        # ----------------------------------------------------
        # Step 5: Produce enriched event
        # ----------------------------------------------------
        producer.send(
            topic='discounted-invoices',
            value=invoice
        )

        print(f"✅ Processed invoice → {invoice}")

    except json.JSONDecodeError:
        # ----------------------------------------------------
        # Step 6: Handle malformed JSON safely
        # ----------------------------------------------------
        print(f"❌ Invalid JSON, skipping message: {raw_value}")





# :: Create input topic: invoices2
# kafka-topics.bat --create --topic invoices2 --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

# :: Create output topic: discounted-invoices
# kafka-topics.bat --create --topic discounted-invoices --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

# :: Optional: verify topic creation
# kafka-topics.bat --list --bootstrap-server localhost:9092


# kafka-console-producer.bat --topic invoices2 --bootstrap-server localhost:9092

# {"invoiceId": "INV001", "invoiceAmount": 1200}
# {"invoiceId": "INV002", "invoiceAmount": 800}
# {"invoiceId": "INV003", "invoiceAmount": 2000}
