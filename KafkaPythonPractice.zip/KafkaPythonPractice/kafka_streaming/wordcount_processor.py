"""
Kafka Streaming Word Count – Python Processor
=============================================

Purpose:
- Consumes text messages from a Kafka topic
- Performs a running (stateful) word count
- Publishes updated word counts to another Kafka topic

Use Case:
- Classic streaming word count example
- Demonstrates Kafka Consumer + Producer together
- Shows stateful stream processing outside Spark/Flink

Architecture:
Kafka Topic (wordcount-input)
        ↓
Python Stream Processor (this script)
        ↓
Kafka Topic (wordcount-result)
"""

from kafka import KafkaConsumer, KafkaProducer
from collections import defaultdict
import re

# --------------------------------------------------
# 1️⃣ INITIAL SETUP
# --------------------------------------------------

# Regex pattern to split text into words
# \W+ → split on any non-word character (spaces, punctuation, etc.)
pattern = re.compile(r'\W+')

# In-memory state store for word counts
# defaultdict(int) initializes missing keys with 0
word_counts = defaultdict(int)

# --------------------------------------------------
# 2️⃣ KAFKA CONSUMER CONFIGURATION
# --------------------------------------------------
consumer = KafkaConsumer(
    # Source topic containing raw text lines
    'wordcount-input',

    # Kafka broker(s)
    bootstrap_servers='localhost:9092',

    # Consumer group ID
    # Allows offset tracking and horizontal scaling
    group_id='wordcount-python-group',

    # Start from beginning if no committed offset exists
    auto_offset_reset='earliest',

    # Automatically commit offsets after processing
    enable_auto_commit=True
)

# --------------------------------------------------
# 3️⃣ KAFKA PRODUCER CONFIGURATION
# --------------------------------------------------
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',

    # Serialize message key (word) to bytes
    key_serializer=lambda k: k.encode('utf-8'),

    # Serialize message value (count) to bytes
    value_serializer=lambda v: str(v).encode('utf-8')
)

print("🔄 Listening on 'wordcount-input' topic...\n")

# --------------------------------------------------
# 4️⃣ STREAM PROCESSING LOOP
# --------------------------------------------------
try:
    # KafkaConsumer is iterable and runs continuously
    for message in consumer:

        # Decode incoming message (bytes → string)
        # Convert to lowercase for case-insensitive counting
        line = message.value.decode('utf-8').lower()

        # Split line into individual words
        words = pattern.split(line)

        # Process each word
        for word in words:

            # Ignore empty strings and common stopword "the"
            if word and word != "the":

                # Update running count (stateful operation)
                word_counts[word] += 1

                # Log current count locally
                print(f"📊 {word} = {word_counts[word]}")

                # Publish updated count to output topic
                producer.send(
                    topic="wordcount-result",
                    key=word,
                    value=str(word_counts[word])
                )

                # Flush ensures message is sent immediately
                # (good for demos; avoid per-message flush in production)
                producer.flush()

except KeyboardInterrupt:
    # Graceful shutdown on Ctrl + C
    print("\n🛑 Word count processor stopped by user.")

finally:
    # --------------------------------------------------
    # 5️⃣ CLEAN SHUTDOWN
    # --------------------------------------------------
    consumer.close()
    print("✅ Kafka consumer closed cleanly.")


#kafka-console-producer.bat --bootstrap-server localhost:9092 --topic wordcount-input

# Type text (this is your input)

# hello kafka hello world
# kafka streaming is powerful
# hello world