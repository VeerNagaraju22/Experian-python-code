from kafka import KafkaConsumer, KafkaProducer
from collections import defaultdict
from datetime import datetime, timedelta
import threading
import time
import json

"""
Kafka Stateful Window Processing – Educational Implementation
=============================================================

Purpose:
- Consume invoice events from Kafka
- Apply three different windowing strategies manually:
  1. Tumbling Window
  2. Hopping Window
  3. Session Window
- Emit aggregated results back to Kafka

⚠️ This is NOT Spark or Kafka Streams.
⚠️ This demonstrates how windowing works internally.
"""


# ============================================================
# 1️⃣ SHARED KAFKA CONFIGURATION
# ============================================================
BOOTSTRAP = 'localhost:9092'

producer = KafkaProducer(
    bootstrap_servers=BOOTSTRAP,
    key_serializer=lambda k: k.encode('utf-8'),
    value_serializer=lambda v: str(v).encode('utf-8')
)


# ============================================================
# 2️⃣ TUMBLING WINDOW (Fixed, Non-Overlapping)
# ============================================================
# Example:
# |----30s----|----30s----|----30s----|

TUMBLING_WINDOW_SEC = 30
tumbling_counts = defaultdict(int)

def flush_tumbling():
    """
    Flushes counts every 30 seconds.
    All events belong to exactly ONE window.
    """
    now = datetime.now()

    for k, v in tumbling_counts.items():
        key = f"{k}-tumbling@{now.strftime('%H:%M:%S')}"
        producer.send('window-tumbling', key=key, value=v)
        print(f"🧱 Tumbling → {key} = {v}")

    tumbling_counts.clear()

    # Schedule next flush
    threading.Timer(TUMBLING_WINDOW_SEC, flush_tumbling).start()


# ============================================================
# 3️⃣ HOPPING WINDOW (Overlapping)
# ============================================================
# Window size = 60s
# Hop every = 30s
#
# |------60s------|
#        |------60s------|
#               |------60s------|

HOP_WINDOW = 60
HOP_STEP = 30
hopping_windows = []

def new_hop_window():
    now = datetime.now()
    return {
        'start': now,
        'end': now + timedelta(seconds=HOP_WINDOW),
        'counts': defaultdict(int)
    }

def flush_hopping():
    """
    Emits completed hopping windows
    and creates a new overlapping window.
    """
    now = datetime.now()

    for window in hopping_windows[:]:
        if now >= window['end']:
            for k, v in window['counts'].items():
                key = f"{k}-hopping@{window['start'].strftime('%H:%M:%S')}"
                producer.send('window-hopping', key=key, value=v)
                print(f"🔁 Hopping → {key} = {v}")

            hopping_windows.remove(window)

    # Add a new overlapping window
    hopping_windows.append(new_hop_window())

    threading.Timer(HOP_STEP, flush_hopping).start()


# ============================================================
# 4️⃣ SESSION WINDOW (Activity-Based)
# ============================================================
# Session closes when user is inactive for SESSION_GAP seconds

SESSION_GAP = 10
sessions = {}

def flush_sessions():
    """
    Ends sessions when inactivity exceeds SESSION_GAP.
    """
    now = time.time()

    for k in list(sessions.keys()):
        if now - sessions[k]['last'] > SESSION_GAP:
            key = f"{k}-session@{datetime.fromtimestamp(sessions[k]['last']).strftime('%H:%M:%S')}"
            producer.send('window-session', key=key, value=sessions[k]['count'])
            print(f"⏳ Session → {key} = {sessions[k]['count']}")
            del sessions[k]

    threading.Timer(SESSION_GAP, flush_sessions).start()


# ============================================================
# 5️⃣ START WINDOW TIMERS
# ============================================================
flush_tumbling()
flush_hopping()
flush_sessions()


# ============================================================
# 6️⃣ KAFKA CONSUMER (SOURCE STREAM)
# ============================================================
consumer = KafkaConsumer(
    'invoices1',
    bootstrap_servers=BOOTSTRAP,
    group_id='windows-group',
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    key_deserializer=lambda x: x.decode('utf-8'),
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

print("🪟 Window processing started: Tumbling | Hopping | Session\n")


# ============================================================
# 7️⃣ EVENT PROCESSING LOOP
# ============================================================
for msg in consumer:
    key = msg.key
    now_dt = datetime.now()
    now_ts = time.time()

    # ----------------------------
    # Tumbling Window Update
    # ----------------------------
    tumbling_counts[key] += 1

    # ----------------------------
    # Hopping Window Update
    # ----------------------------
    for window in hopping_windows:
        if window['start'] <= now_dt <= window['end']:
            window['counts'][key] += 1

    # ----------------------------
    # Session Window Update
    # ----------------------------
    if key not in sessions:
        sessions[key] = {'last': now_ts, 'count': 1}
    else:
        sessions[key]['last'] = now_ts
        sessions[key]['count'] += 1


# kafka-topics.bat --bootstrap-server localhost:9092 --create --topic invoices1 --partitions 3 --replication-factor 1
# kafka-topics.bat --bootstrap-server localhost:9092 --create --topic window-tumbling --partitions 3 --replication-factor 1
# kafka-topics.bat --bootstrap-server localhost:9092 --create --topic window-hopping --partitions 3 --replication-factor 1
# kafka-topics.bat --bootstrap-server localhost:9092 --create --topic window-session --partitions 3 --replication-factor 1



# ✅ Tumbling Window Output 
# kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic window-tumbling --from-beginning --property print.key=true --property key.separator=" -> "

# ✅ Hopping Window Output 

# kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic window-hopping --from-beginning --property print.key=true --property key.separator=" -> "

# ✅ Session Window Output 
# kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic window-session --from-beginning --property print.key=true --property key.separator=" -> "
