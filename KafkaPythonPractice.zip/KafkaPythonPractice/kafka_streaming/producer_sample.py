from kafka import KafkaProducer
import time
import random
import json

"""
Kafka Producer – Invoice Event Simulator
========================================

Purpose:
- Simulates real-time invoice events
- Sends JSON messages to a Kafka topic
- Uses message keys to ensure ordering per user
- Suitable for testing streaming systems (Spark, Flink, etc.)

Architecture:
Event Generator → Kafka Producer → Kafka Topic (invoices1)

Message Characteristics:
- Key   : User identifier (A, B, C)
- Value : Invoice data in JSON format
- Event Time : Included explicitly for windowed processing
"""


# ============================================================
# 1️⃣ KAFKA PRODUCER CONFIGURATION
# ============================================================
# bootstrap_servers:
# - Initial Kafka broker(s) used to discover cluster metadata
#
# key_serializer:
# - Converts message key from string → bytes
#
# value_serializer:
# - Converts Python dict → JSON → bytes

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    key_serializer=lambda k: k.encode('utf-8'),
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)


# ============================================================
# 2️⃣ SIMULATED USERS (MESSAGE KEYS)
# ============================================================
# Message keys are important because:
# - Kafka uses keys to decide partition assignment
# - Messages with the same key always go to the same partition
# - Ordering is preserved per key

keys = ['A', 'B', 'C']  # Simulate three different users/accounts

print("🚀 Kafka Producer started – sending simulated invoice events...\n")


# ============================================================
# 3️⃣ CONTINUOUS EVENT GENERATION LOOP
# ============================================================
# Each iteration represents one invoice event.
# Events are sent at random intervals to simulate real traffic.

while True:
    # Randomly select a user (key)
    key = random.choice(keys)

    # Create invoice payload
    invoice = {
        "invoiceId": random.randint(1000, 9999),
        "invoiceAmount": random.randint(500, 2000),
        "timestamp": int(time.time() * 1000)  # Event time in milliseconds
    }

    # Send event asynchronously to Kafka topic
    producer.send(
        topic='invoices1',
        key=key,
        value=invoice
    )

    # Log sent message (for visibility)
    print(f"📤 Sent → Key: {key} | Value: {invoice}")

    # Wait 1–3 seconds before sending next event
    # This simulates irregular real-world data arrival
    time.sleep(random.uniform(1, 3))
