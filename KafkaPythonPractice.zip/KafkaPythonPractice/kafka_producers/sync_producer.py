from kafka import KafkaProducer
from kafka.errors import KafkaError
import hashlib

# ============================================================
# Kafka Producer – Synchronous Message Publishing
# ============================================================
# Purpose:
# This script publishes messages to an Apache Kafka topic
# using a synchronous (blocking) send approach.
#
# For each message:
# - The producer waits for broker acknowledgements
# - Delivery metadata (topic, partition, offset) is captured
# - A hash is generated for traceability/logging
#
# This pattern is commonly used where delivery guarantees,
# auditing, or debugging are required.
# ============================================================


# ------------------------------------------------------------
# Kafka Configuration
# ------------------------------------------------------------
# Kafka broker address.
# Using an IP address instead of 'localhost' avoids
# hostname resolution issues in certain environments.
BOOTSTRAP_SERVERS = ['127.0.0.1:9092']

# Target Kafka topic.
# Ensure this topic already exists in the Kafka cluster.
TOPIC_NAME = 'mytopic'


# ------------------------------------------------------------
# Kafka Producer Initialization
# ------------------------------------------------------------
# The KafkaProducer handles:
# - Connection to Kafka brokers
# - Serialization of message payloads
# - Reliability settings (acks, retries)
# - Message compression and batching
producer = KafkaProducer(
    # Kafka broker connection details
    bootstrap_servers=BOOTSTRAP_SERVERS,

    # Convert message value from string to bytes
    # Kafka transmits only byte data
    value_serializer=lambda v: v.encode('utf-8'),

    # Wait for acknowledgements from all in-sync replicas
    # Provides strongest durability guarantee
    acks='all',

    # Number of retries in case of transient send failures
    retries=5,

    # Time (in milliseconds) to wait for additional messages
    # before sending a batch to Kafka
    linger_ms=100,

    # Compress messages to reduce network usage and
    # improve throughput
    compression_type='gzip',

    # Explicit Kafka API version to avoid auto-negotiation
    # and compatibility issues
    api_version=(3, 6, 1)
)

print("✅ Kafka Producer started in synchronous mode\n")


# ------------------------------------------------------------
# Synchronous Message Publishing
# ------------------------------------------------------------
# Messages are sent one by one.
# The producer blocks until Kafka acknowledges each message
# or a timeout/error occurs.
try:
    for i in range(5):
        # Construct message payload
        message = f"Hello Kafka message {i}"

        print(f"⏳ Sending message {i}...")

        # Send the message asynchronously and obtain a Future
        future = producer.send(
            TOPIC_NAME,
            value=message
        )

        # Block until Kafka acknowledges the message
        # and returns metadata
        metadata = future.get(timeout=30)

        # Generate a hash from message metadata
        # Useful for logging, tracing, or audit purposes
        meta_hash = hashlib.md5(
            f"{metadata.topic}-{metadata.partition}-{metadata.offset}".encode()
        ).hexdigest()

        # Log successful delivery information
        print(f"✅ Message {i} delivered successfully")
        print(f"   • Topic     : {metadata.topic}")
        print(f"   • Partition : {metadata.partition}")
        print(f"   • Offset    : {metadata.offset}")
        print(f"   • Hash      : {meta_hash}")
        print("-" * 50)


# ------------------------------------------------------------
# Error Handling
# ------------------------------------------------------------
# Handles Kafka-specific exceptions such as broker
# unavailability, timeouts, or delivery failures.
except KafkaError as e:
    print(f"❌ Kafka Error occurred: {e}")

# Handles unexpected runtime exceptions
except Exception as e:
    print(f"❌ General Error occurred: {e}")


# ------------------------------------------------------------
# Graceful Shutdown
# ------------------------------------------------------------
# Ensures all buffered messages are flushed to Kafka
# and releases producer resources cleanly.
finally:
    producer.flush()
    producer.close()
    print("\n✅ Kafka Producer closed gracefully")
