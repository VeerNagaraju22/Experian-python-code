from kafka import KafkaProducer
import json
import time

# ============================================================
# Kafka Producer – JSON Message Publishing (Python)
# ============================================================
# Purpose:
# This script demonstrates how to publish JSON-formatted
# messages to an Apache Kafka topic using the kafka-python
# client library.
#
# Each message is serialized as JSON and sent to Kafka
# at regular time intervals.
# ============================================================


# ------------------------------------------------------------
# Kafka Broker and Topic Configuration
# ------------------------------------------------------------
# Address of the Kafka broker.
# In a local setup, Kafka typically runs on localhost:9092.
bootstrap_servers = ['localhost:9092']

# Name of the Kafka topic to which messages will be published.
# Ensure that this topic exists before running the producer.
topic_name = 'mytopic'


# ------------------------------------------------------------
# KafkaProducer Initialization
# ------------------------------------------------------------
# The KafkaProducer is responsible for:
# - Establishing a connection to the Kafka broker
# - Serializing Python objects into bytes
# - Sending messages asynchronously to Kafka
producer = KafkaProducer(
    # Kafka broker connection details
    bootstrap_servers=bootstrap_servers,

    # Serialize Python dictionaries into JSON-encoded bytes
    # Kafka transmits data only in byte format
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),

    # Explicit Kafka API version for compatibility
    api_version=(3, 6, 1)
)

print("🚀 Kafka Producer initialized and started.")


# ------------------------------------------------------------
# Message Production Loop
# ------------------------------------------------------------
# Sends multiple JSON messages to the Kafka topic.
# Each message contains a simple payload with an ID,
# a name, and a text message.
for i in range(1, 11):
    # Construct the message payload
    message = {
        'id': i,
        'name': 'Varma',
        'message': f'Hello Kafka! Message number {i}'
    }

    # Asynchronously send the message to the Kafka topic
    producer.send(topic_name, message)

    # Log the sent message for visibility
    print(f"✅ Sent message {i}: {message}")

    # Optional delay to simulate real-time message generation
    time.sleep(1)


# ------------------------------------------------------------
# Flush and Shutdown
# ------------------------------------------------------------
# Ensure that all buffered messages are transmitted
# to Kafka before the application exits.
producer.flush()
print("\n🎉 All messages sent successfully to topic:", topic_name)
