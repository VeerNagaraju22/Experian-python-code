from kafka import KafkaProducer
from kafka.errors import KafkaError
import hashlib

# ============================================================
# 1️⃣ KAFKA PRODUCER CONFIGURATION
# ============================================================
# BOOTSTRAP_SERVERS:
# - Initial Kafka broker(s) used to discover the cluster
#
# TOPIC_NAME:
# - Destination topic for messages

BOOTSTRAP_SERVERS = ['localhost:9092']
TOPIC_NAME = 'mytopic'


# ============================================================
# 2️⃣ CALLBACK FUNCTIONS (ASYNC DELIVERY REPORTING)
# ============================================================
# These callbacks are executed asynchronously by Kafka's I/O thread.
# They DO NOT block the producer send loop.

def on_send_success(record_metadata, key_index):
    """
    Called when a message is successfully acknowledged by Kafka.

    record_metadata contains:
    - topic
    - partition
    - offset
    - timestamp

    We generate a hash purely for traceability and logging.
    """

    meta_hash = hashlib.md5(
        f"{record_metadata.topic}-"
        f"{record_metadata.partition}-"
        f"{record_metadata.offset}".encode()
    ).hexdigest()

    print("🟢 Message delivered successfully")
    print(f"    • Topic     : {record_metadata.topic}")
    print(f"    • Partition : {record_metadata.partition}")
    print(f"    • Offset    : {record_metadata.offset}")
    print(f"    • Timestamp : {record_metadata.timestamp}")
    print(f"    • Hash      : {meta_hash}")
    print(f"    • Message # : {key_index}")
    print("-" * 50)


def on_send_error(exception):
    """
    Called if Kafka fails to deliver the message.
    Common causes:
    - Broker unavailable
    - Serialization error
    - Authorization failure
    """

    print("❌ Message delivery failed")
    print(f"    Error: {exception}")
    print("-" * 50)


# ============================================================
# 3️⃣ CREATE KAFKA PRODUCER
# ============================================================
# Important tuning parameters explained:
#
# key_serializer / value_serializer:
#   → Convert Python strings → bytes (Kafka requirement)
#
# batch_size:
#   → Max bytes per batch before sending to broker
#
# linger_ms:
#   → Wait time to accumulate more messages before sending
#
# compression_type='gzip':
#   → Reduces network usage (CPU ↔ bandwidth tradeoff)
#
# api_version:
#   → Explicit compatibility with Kafka broker

producer = KafkaProducer(
    bootstrap_servers=BOOTSTRAP_SERVERS,
    key_serializer=lambda k: k.encode('utf-8'),
    value_serializer=lambda v: v.encode('utf-8'),
    batch_size=20480,
    linger_ms=1000,
    compression_type='gzip',
    api_version=(3, 6, 1)
)

print("✅ Kafka Asynchronous Producer started\n")


# ============================================================
# 4️⃣ SEND MESSAGES ASYNCHRONOUSLY
# ============================================================
# producer.send():
# - Returns a FutureRecordMetadata object
# - Message is placed into internal buffer
# - Sent by background Kafka thread

for i in range(10):
    key = f"Key {i}"
    value = f"Python KafkaProducerAsync Value {i}"

    future = producer.send(
        topic=TOPIC_NAME,
        key=key,
        value=value
    )

    # Attach success & failure callbacks
    future.add_callback(lambda metadata, i=i: on_send_success(metadata, i))
    future.add_errback(lambda excp, i=i: on_send_error(excp))

    print(f"📤 Queued async message #{i} for topic '{TOPIC_NAME}'")


# ============================================================
# 5️⃣ FLUSH & CLEAN SHUTDOWN
# ============================================================
# producer.close():
# - Flushes all pending messages
# - Blocks until all sends are completed
# - Closes network connections

producer.close()
print("\n✅ Kafka Async Producer closed cleanly")
