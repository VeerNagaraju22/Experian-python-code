from kafka import KafkaProducer
import time

# ============================================================
# Kafka Producer – Python
# ------------------------------------------------------------
# Purpose:
# This script demonstrates how to produce messages to an
# Apache Kafka topic using the kafka-python library.
#
# It sends a series of messages with keys and values to Kafka,
# using batching, retries, and compression for efficiency.
# ============================================================


# ------------------------------------------------------------
# Kafka Broker Configuration
# ------------------------------------------------------------
# List of Kafka brokers the producer will connect to.
# In a local setup, Kafka typically runs on localhost:9092.
bootstrap_servers = ['localhost:9092']

# Name of the Kafka topic to which messages will be published.
topic_name = 'mytopicnew'


# ------------------------------------------------------------
# KafkaProducer Initialization
# ------------------------------------------------------------
# The KafkaProducer is responsible for:
# - Connecting to the Kafka broker
# - Serializing message keys and values
# - Batching records for performance
# - Retrying sends in case of temporary failures
producer = KafkaProducer(
    # Kafka broker connection details
    bootstrap_servers=bootstrap_servers,

    # Serializer functions convert Python strings into bytes.
    # Kafka transmits data only in byte format.
    key_serializer=lambda k: k.encode('utf-8'),
    value_serializer=lambda v: v.encode('utf-8'),

    # Maximum size (in bytes) of a batch of records sent to Kafka.
    # Messages are accumulated until this size is reached
    # or linger_ms expires.
    batch_size=20480,   # 20 KB

    # Time (in milliseconds) to wait before sending a batch.
    # Allows more messages to accumulate for better throughput.
    linger_ms=10,       # 10 ms batching delay

    # Number of retry attempts if a send fails due to
    # transient errors (e.g., network hiccups).
    retries=2,

    # Compress messages to reduce network usage and improve
    # throughput. 'gzip' is widely supported and stable.
    compression_type='gzip',

    # Explicitly specify Kafka API version to avoid
    # auto-detection delays or mismatches.
    api_version=(3, 6, 1)
)

print("✅ Kafka Producer initialized and ready to send messages.")


# ------------------------------------------------------------
# Message Production Logic
# ------------------------------------------------------------
# Sends a sequence of messages to the Kafka topic.
# Each message contains:
# - A unique key (used by Kafka for partitioning)
# - A simple text payload as the value
try:
    for i in range(20):
        # Message key: used by Kafka to determine partition
        key = f"MyKey{i}"

        # Message value: actual payload sent to Kafka
        value = f"Test Python Message {i}"

        # Asynchronously send the message to Kafka.
        # The call returns immediately; Kafka sends in background.
        producer.send(
            topic_name,
            key=key,
            value=value
        )

        # Log message send for visibility during execution
        print(f"📤 Sent message | Key: {key} | Value: {value}")

        # Small delay to simulate real-time message generation
        time.sleep(0.01)

# ------------------------------------------------------------
# Error Handling
# ------------------------------------------------------------
# Catches and logs any exception that occurs during
# message production.
except Exception as e:
    print(f"❌ Error while sending messages: {e}")

# ------------------------------------------------------------
# Graceful Shutdown
# ------------------------------------------------------------
# Ensures all buffered messages are sent to Kafka
# before closing the producer and releasing resources.
finally:
    producer.flush()
    producer.close()
    print("✅ Kafka Producer closed gracefully.")
